f = open("smiley.pbm", "r")
g = open("negatif smiley.pbm", "w")
entete = f.readline()
g.write(entete)
definition = f.readline()
g.write(definition)
largeur,hauteur = definition.split(" ")
largeur = int(largeur)
hauteur = int(hauteur)
for lig in range(hauteur):
    for col in range(largeur):
        pix = f.read(1)
        if pix == '0':
            pix = '1'
        else:
            pix = '0'
        g.write(pix)
    f.read(1)
    g.write('\n')
f.close()
g.close()
