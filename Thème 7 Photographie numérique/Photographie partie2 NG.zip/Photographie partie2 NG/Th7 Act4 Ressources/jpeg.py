from PIL import Image
im = Image.open('VTT.jpg')
largeur = im.size[0]
hauteur = im.size[1]
im2 = Image.new('RGB', (largeur,hauteur))
for lig in range(hauteur):
    for col in range(largeur):
        (r,g,b) = im.getpixel((col,lig))
        r = 0
        g = 0
        im2.putpixel((col,lig), (r,g,b))
im2.save('VTT bleu.jpg')
