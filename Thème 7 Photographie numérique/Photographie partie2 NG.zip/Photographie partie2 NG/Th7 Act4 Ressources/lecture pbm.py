f = open("smiley.pbm", "r")
entete = f.readline()
definition = f.readline()
largeur,hauteur = definition.split(" ")
largeur = int(largeur)
hauteur = int(hauteur)
for lig in range(hauteur):
    for col in range(largeur):
        pix = f.read(1)
        print(pix, end='')
    f.read(1)
    print()
f.close()
