f = open("chat.pbm", "r")
g = open("negatif chat.pbm", "w")
entete = f.readline()
g.write(entete)
definition = f.readline()
g.write(definition)
largeur,hauteur = definition.split(" ")
largeur = int(largeur)
hauteur = int(hauteur)
for lig in range(hauteur):
    for col in range(largeur):
        pix = f.read(1)
        if pix == '0':
            g.write('1')
        else:  
            g.write('0')
    f.read(1)
    g.write('\n')
f.close()
g.close()
