from PIL import Image
im = Image.open('VTT.jpg')
largeur = im.size[0]
hauteur = im.size[1]
im2 = Image.new('RGB', (largeur,hauteur))
for lig in range(hauteur):
    for col in range(largeur):
        (r,g,b) = im.getpixel((col,lig))
        gris = int(0.2126*r+0.7152*g+0.0722*b)
        im2.putpixel((col,lig), (gris,gris,gris))
im2.save('VTT nivdegris.jpg')
